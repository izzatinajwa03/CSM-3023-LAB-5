package laab5.com;

/**
 *
 * @author User
 */
public class Register {
    
    private String icno;
    private String name;
    private String typetraining;
    private int pax;
    private String stud;

    public void seticno(String icno) {
        this.icno = icno;
    }
    
    public String geticno() {
        return icno;
    }

    public void setname(String name) {
        this.name = name;
    }
    
    public String getname() {
        return name;
    }
    
    public void settypetraining(String typetraining) {
        this.typetraining = typetraining;
    }
    
    public String gettypetraining() {
        return typetraining;
    }

    public void setpax(int pax) {
        this.pax = pax;
    }
    
    public int getpax() {
        return pax;
    }

    public void setstud(String stud) {
        this.stud = stud;
    }
    
    public String getstud() {
        return stud;
    }
}
