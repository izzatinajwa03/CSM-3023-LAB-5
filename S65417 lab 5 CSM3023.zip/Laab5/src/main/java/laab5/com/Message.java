
package laab5.com;
/**
 *
 * s65417 izzati najwa
 */
public class Message {
    
    private String Msg;
    
    public Message() {
        this.Msg = Msg;
    }
    
    public void setMsg (String Msg) {
        this.Msg = Msg;
    }
    
    public String getMsg() {
        return Msg;
    }
}
